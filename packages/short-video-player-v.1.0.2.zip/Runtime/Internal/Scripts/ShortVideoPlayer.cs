using UdonSharp;
using UnityEngine;
using VRC.SDK3.StringLoading;
using VRC.SDKBase;
using VRC.Udon.Common.Interfaces;
using Yamadev.YamaStream;

[UdonBehaviourSyncMode(BehaviourSyncMode.None)]
public class ShortVideoPlayer : UdonSharpBehaviour
{
    [SerializeField] Controller _yamaController;
    [SerializeField] VRCUrl _apiUrl;    // https://shortvideo-world.shortvideo-world.workers.dev/videos
    [SerializeField] VRCUrl[] _urlPool; // /vrcurl/0 〜 /vrcurl/2999 をEditorスクリプトで焼き込む

    bool _isLoading = false;

    // ボタンから呼ぶ
    public void FetchAndEnqueue()
    {
        if (_isLoading) return;

        if (_yamaController.Queue.Length >= 100)
        {
            _yamaController.ShowErrorModalToAllListeners(
                "ショート動画を追加できません",
                "キューに100件以上の動画があります。動画を再生してキューを消化してください。"
            );
            return;
        }

        _isLoading = true;
        VRCStringDownloader.LoadUrl(_apiUrl, (IUdonEventReceiver)this);
    }

    public override void OnStringLoadSuccess(IVRCStringDownload result)
    {
        _isLoading = false;

        // JSONパース: {"indices":[42,7,...],"titles":"タイトル1|タイトル2|...","count":100,...}
        string json = result.Result;

        // indicesパース
        int indicesStart = json.IndexOf("[");
        int indicesEnd = json.IndexOf("]");
        if (indicesStart < 0 || indicesEnd < 0) return;
        string indicesStr = json.Substring(indicesStart + 1, indicesEnd - indicesStart - 1);
        string[] indexParts = indicesStr.Split(',');

        // titlesパース
        string[] titles = new string[0];
        int titlesKeyPos = json.IndexOf("\"titles\":");
        if (titlesKeyPos >= 0)
        {
            int titlesStart = json.IndexOf("\"", titlesKeyPos + 9) + 1;
            int titlesEnd = json.IndexOf("\"", titlesStart);
            if (titlesStart > 0 && titlesEnd > titlesStart)
            {
                string titlesStr = json.Substring(titlesStart, titlesEnd - titlesStart);
                titles = titlesStr.Split('|');
            }
        }

        // 有効なトラックを先に収集
        Playlist queue = _yamaController.Queue;
        VRCUrl[] urls = new VRCUrl[indexParts.Length];
        string[] trackTitles = new string[indexParts.Length];
        int trackCount = 0;

        for (int i = 0; i < indexParts.Length; i++)
        {
            string trimmed = indexParts[i].Trim();
            if (!int.TryParse(trimmed, out int index)) continue;
            if (index < 0 || index >= _urlPool.Length) continue;

            urls[trackCount] = _urlPool[index];
            trackTitles[trackCount] = i < titles.Length ? titles[i] : string.Empty;
            trackCount++;
        }

        if (trackCount == 0) return;

        // 1曲目を即再生（キューに重複があれば削除）
        queue.TakeOwnership();
        RemoveDuplicateFromQueue(queue, urls[0]);
        _yamaController.TakeOwnership();
        _yamaController.PlayTrack(Track.New(VideoPlayerType.AVProVideoPlayer, trackTitles[0], urls[0]));

        // 2曲目以降をキュー先頭に割り込み（逆順でindex 0に挿入、重複削除）
        for (int i = trackCount - 1; i >= 1; i--)
        {
            RemoveDuplicateFromQueue(queue, urls[i]);
            queue.InsertTrack(0, Track.New(VideoPlayerType.AVProVideoPlayer, trackTitles[i], urls[i]));
        }
    }

    void RemoveDuplicateFromQueue(Playlist queue, VRCUrl url)
    {
        string urlStr = url.Get();
        for (int k = queue.Length - 1; k >= 0; k--)
        {
            if (queue.GetTrack(k).GetVRCUrl().Get() == urlStr)
                queue.RemoveTrack(k);
        }
    }

    public override void OnStringLoadError(IVRCStringDownload result)
    {
        _isLoading = false;
        Debug.LogError($"[ShortVideoPlayer] 動画リスト取得失敗: {result.ErrorCode} {result.Error}");
    }
}
