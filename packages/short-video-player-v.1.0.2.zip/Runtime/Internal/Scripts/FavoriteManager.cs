using UdonSharp;
using UnityEngine;
using VRC.SDKBase;

namespace Yamadev.YamaStream
{
    [UdonBehaviourSyncMode(BehaviourSyncMode.Manual)]
    public class FavoriteManager : UdonSharpBehaviour
    {
        [Header("Default Video")]
        [Tooltip("Played on instance join when no pinned/synced default video exists")]
        [SerializeField] private VRCUrl _fallbackUrl;
        [SerializeField] private string _fallbackTitle;

        [Header("Video Settings")]
        [Tooltip("Total limit for favorite videos")]
        [SerializeField]
        public int maxFavoriteItems = 16;

        [Tooltip("Enforce limit per user for favorite videos")]
        [SerializeField]
        [UdonSynced]
        public bool videoLimitPerUserEnabled = false;

        [Tooltip("Allow users to enter custom urls.")]
        [SerializeField]
        [UdonSynced]
        public bool customUrlInputEnabled = true;

        [Tooltip("Individual limit per user for favorite videos")]
        [SerializeField]
        [UdonSynced]
        public int videoLimitPerUser = 5;

        [Header("Folder Settings")]
        [Tooltip("Total limit for folders")]
        [SerializeField]
        public int maxFolderItems = 20;

        [UdonSynced] private VRCUrl[] favoriteUrls = new VRCUrl[0];
        [UdonSynced] private string[] favoriteTitles = new string[0];
        [UdonSynced] private string[] _folderNames = new string[0];
        [UdonSynced] private int[] _favoriteFolderIndices = new int[0];
        [UdonSynced] public bool isVideoPinned = false;
        public string lastDuplicateFolderName = "";

        public bool toggleVideoPinned()
        {
            isVideoPinned = !isVideoPinned;
            RequestSerialization();
            return isVideoPinned;
        }
        [UdonSynced] private VRCUrl defaultUrl;
        [UdonSynced] private string defaultTitle;
        public void SetDefaultVideo(VRCUrl url, string title)
        {
            if(isVideoPinned){
                return;
            }
            defaultUrl = url;
            defaultTitle = title;
            RequestSerialization();
        }

        public int AddFavorite(VRCUrl url, string title = null)
        {
            if (!IsLocalPlayerPermittedToAddFavorite())
            {
                Debug.LogWarning("[FavoriteManager] Player not permitted to add favorite");
                return 401; // 権限なし
            }

            if (favoriteUrls.Length >= maxFavoriteItems)
            {
                Debug.LogWarning($"[FavoriteManager] Cannot add more favorites. Maximum limit ({maxFavoriteItems}) reached.");
                return 403; // 上限到達
            }

            if (url == null || string.IsNullOrEmpty(url.Get()))
            {
                Debug.LogWarning("[FavoriteManager] Empty URL detected, skipping");
                return 422; // 空のURL
            }

            // シンプルなURLバリデーション
            string urlStr = url.Get();
            int idx = urlStr.IndexOf("://", System.StringComparison.Ordinal);
            if (idx < 1 || idx > 8)
            {
                Debug.LogWarning("[FavoriteManager] Invalid URL format");
                return 400; // 無効なURL形式
            }

            // このプレイヤーの既存お気に入り内での重複チェック
            for (int i = 0; i < favoriteUrls.Length; i++)
            {
                if (favoriteUrls[i] != null && favoriteUrls[i].Get() == urlStr)
                {
                    Debug.LogWarning("[FavoriteManager] Duplicate URL detected, skipping");
                    int folderIdx = i < _favoriteFolderIndices.Length ? _favoriteFolderIndices[i] : -1;
                    lastDuplicateFolderName = (folderIdx >= 0 && folderIdx < _folderNames.Length)
                        ? _folderNames[folderIdx]
                        : "";
                    return 409; // 重複
                }
            }

            EnsureOwnership();

            Debug.Log($"[FavoriteManager] Adding favorite - URL: {url.Get()}, Title: {title}");

            // 配列を拡張
            VRCUrl[] newUrls = new VRCUrl[favoriteUrls.Length + 1];
            string[] newTitles = new string[favoriteTitles.Length + 1];
            int[] newFolderIndices = new int[_favoriteFolderIndices.Length + 1];

            // 既存のデータをコピー
            favoriteUrls.CopyTo(newUrls, 0);
            favoriteTitles.CopyTo(newTitles, 0);
            _favoriteFolderIndices.CopyTo(newFolderIndices, 0);

            // 新しいデータを追加
            newUrls[favoriteUrls.Length] = url;
            newTitles[favoriteTitles.Length] = title ?? url.Get();
            newFolderIndices[_favoriteFolderIndices.Length] = -1; // 未分類

            // 配列を更新
            favoriteUrls = newUrls;
            favoriteTitles = newTitles;
            _favoriteFolderIndices = newFolderIndices;

            Debug.Log($"[FavoriteManager] Successfully added favorite. New count: {favoriteUrls.Length}");

            customUrlInputEnabled = true;
            RequestSerialization();
            return 200; // 成功
        }

        public int RemoveFavorite(int index)
        {
            if (index < 0 || index >= favoriteUrls.Length)
            {
                return 400; // 無効なインデックス
            }
            
            if (!IsLocalPlayerPermittedToRemoveVideo(index))
            {
                return 401; // 権限なし
            }

            EnsureOwnership();

            // 新しい配列を作成
            VRCUrl[] newUrls = new VRCUrl[favoriteUrls.Length - 1];
            string[] newTitles = new string[favoriteTitles.Length - 1];
            int[] newFolderIndices = new int[_favoriteFolderIndices.Length - 1];

            // インデックスをスキップしてコピー
            int newIndex = 0;
            for (int i = 0; i < favoriteUrls.Length; i++)
            {
                if (i == index) continue;
                newUrls[newIndex] = favoriteUrls[i];
                newTitles[newIndex] = favoriteTitles[i];
                if (i < _favoriteFolderIndices.Length)
                    newFolderIndices[newIndex] = _favoriteFolderIndices[i];
                newIndex++;
            }

            // 配列を更新
            favoriteUrls = newUrls;
            favoriteTitles = newTitles;
            _favoriteFolderIndices = newFolderIndices;

            RequestSerialization();
            return 200; // 成功
        }

        public int UpdateFavoriteTitle(int index, string newTitle)
        {
            if (index < 0 || index >= favoriteTitles.Length)
                return 400;
            EnsureOwnership();
            favoriteTitles[index] = newTitle;
            RequestSerialization();
            return 200;
        }

        public int FindFavoriteIndex(VRCUrl url)
        {
            if (url == null) return -1;
            string urlStr = url.Get();
            for (int i = 0; i < favoriteUrls.Length; i++)
            {
                if (favoriteUrls[i] != null && favoriteUrls[i].Get() == urlStr)
                {
                    return i;
                }
            }
            return -1;
        }

        public void EnsureOwnership()
        {
            bool wasEnabled = customUrlInputEnabled;
            if (!Networking.IsOwner(gameObject))
            {
                Networking.SetOwner(Networking.LocalPlayer, gameObject);
            }
            customUrlInputEnabled = wasEnabled;
        }

        public VRCUrl[] GetFavoriteUrls()
        {
            return favoriteUrls;
        }

        public string[] GetFavoriteTitles()
        {
            return favoriteTitles;
        }

        public VRCUrl GetFavoriteUrl(int index)
        {
            if (index < 0 || index >= favoriteUrls.Length) return null;
            return favoriteUrls[index];
        }

        public string GetFavoriteTitle(int index)
        {
            if (index < 0 || index >= favoriteTitles.Length) return "";
            return favoriteTitles[index];
        }

        public int GetFavoriteCount()
        {
            return favoriteUrls.Length;
        }

        // ---- フォルダ関連 ----

        public string[] GetFolderNames() => _folderNames;
        public int GetFolderCount() => _folderNames.Length;

        public string GetFolderName(int index)
        {
            if (index < 0 || index >= _folderNames.Length) return "";
            return _folderNames[index];
        }

        public int GetFavoriteFolderIndex(int favoriteIndex)
        {
            if (favoriteIndex < 0 || favoriteIndex >= _favoriteFolderIndices.Length) return -1;
            return _favoriteFolderIndices[favoriteIndex];
        }

        public int AddFolder(string name)
        {
            if (string.IsNullOrEmpty(name)) return 400;
            if (_folderNames.Length >= maxFolderItems) return 403; // 上限到達
            for (int i = 0; i < _folderNames.Length; i++)
                if (_folderNames[i] == name) return 409; // 重複
            EnsureOwnership();
            string[] newFolders = new string[_folderNames.Length + 1];
            _folderNames.CopyTo(newFolders, 0);
            newFolders[_folderNames.Length] = name;
            _folderNames = newFolders;
            RequestSerialization();
            return _folderNames.Length - 1; // 新しい index を返す
        }

        public int RemoveFolder(int folderIndex)
        {
            if (folderIndex < 0 || folderIndex >= _folderNames.Length) return 400;
            EnsureOwnership();
            // 割り当て済み動画を未分類に戻し、後続 index をずらす
            for (int i = 0; i < _favoriteFolderIndices.Length; i++)
            {
                if (_favoriteFolderIndices[i] == folderIndex)
                    _favoriteFolderIndices[i] = -1;
                else if (_favoriteFolderIndices[i] > folderIndex)
                    _favoriteFolderIndices[i]--;
            }
            // フォルダ名配列から削除
            string[] newFolders = new string[_folderNames.Length - 1];
            int j = 0;
            for (int i = 0; i < _folderNames.Length; i++)
            {
                if (i == folderIndex) continue;
                newFolders[j++] = _folderNames[i];
            }
            _folderNames = newFolders;
            RequestSerialization();
            return 200;
        }

        public int RenameFolder(int folderIndex, string newName)
        {
            if (folderIndex < 0 || folderIndex >= _folderNames.Length) return 400;
            if (string.IsNullOrEmpty(newName)) return 400;
            for (int i = 0; i < _folderNames.Length; i++)
                if (i != folderIndex && _folderNames[i] == newName) return 409; // 重複
            EnsureOwnership();
            _folderNames[folderIndex] = newName;
            RequestSerialization();
            return 200;
        }

        public int ReorderFolders(string[] newOrder)
        {
            if (newOrder == null || newOrder.Length != _folderNames.Length) return 400;
            EnsureOwnership();
            // 旧index → 新index の対応表を構築
            int[] oldToNew = new int[_folderNames.Length];
            for (int oldIdx = 0; oldIdx < _folderNames.Length; oldIdx++)
            {
                for (int newIdx = 0; newIdx < newOrder.Length; newIdx++)
                {
                    if (_folderNames[oldIdx] == newOrder[newIdx])
                    {
                        oldToNew[oldIdx] = newIdx;
                        break;
                    }
                }
            }
            // フォルダ名配列を更新
            string[] copied = new string[newOrder.Length];
            for (int i = 0; i < newOrder.Length; i++) copied[i] = newOrder[i];
            _folderNames = copied;
            // 動画のフォルダ参照を更新
            for (int i = 0; i < _favoriteFolderIndices.Length; i++)
            {
                if (_favoriteFolderIndices[i] >= 0 && _favoriteFolderIndices[i] < oldToNew.Length)
                    _favoriteFolderIndices[i] = oldToNew[_favoriteFolderIndices[i]];
            }
            RequestSerialization();
            return 200;
        }

        public int SwapFolder(int indexA, int indexB)
        {
            if (indexA < 0 || indexA >= _folderNames.Length) return 400;
            if (indexB < 0 || indexB >= _folderNames.Length) return 400;
            if (indexA == indexB) return 200;
            EnsureOwnership();
            // フォルダ名を入れ替え
            string tmp = _folderNames[indexA];
            _folderNames[indexA] = _folderNames[indexB];
            _folderNames[indexB] = tmp;
            // 動画のフォルダ参照を更新
            for (int i = 0; i < _favoriteFolderIndices.Length; i++)
            {
                if (_favoriteFolderIndices[i] == indexA)
                    _favoriteFolderIndices[i] = indexB;
                else if (_favoriteFolderIndices[i] == indexB)
                    _favoriteFolderIndices[i] = indexA;
            }
            RequestSerialization();
            return 200;
        }

        public int SetFavoriteFolder(int favoriteIndex, int folderIndex)
        {
            if (favoriteIndex < 0 || favoriteIndex >= _favoriteFolderIndices.Length) return 400;
            if (folderIndex != -1 && (folderIndex < 0 || folderIndex >= _folderNames.Length)) return 400;
            EnsureOwnership();
            _favoriteFolderIndices[favoriteIndex] = folderIndex;
            RequestSerialization();
            return 200;
        }

        public VRCUrl GetDefaultUrl()
        {
            if (defaultUrl != null && !string.IsNullOrEmpty(defaultUrl.Get()))
                return defaultUrl;
            return _fallbackUrl;
        }

        public string GetDefaultTitle()
        {
            if (defaultUrl != null && !string.IsNullOrEmpty(defaultUrl.Get()))
                return defaultTitle;
            return _fallbackTitle;
        }

        public bool IsLocalPlayerPermittedToAddFavorite()
        {
            // ローカルプレイヤーのみ使用するため、常に許可
            return true;
        }

        public bool IsLocalPlayerPermittedToRemoveVideo(int index)
        {
            // ローカルプレイヤーのみ使用するため、常に許可
            return true;
        }

        public override void OnDeserialization()
        {
            Debug.Log($"[FavoriteManager] OnDeserialization - FavoriteCount: {favoriteUrls.Length}");
        }
    }
}

