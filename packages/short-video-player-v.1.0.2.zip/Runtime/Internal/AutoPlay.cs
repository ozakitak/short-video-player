﻿
using UnityEngine;
using UdonSharp;
using VRC.SDKBase;

namespace Yamadev.YamaStream
{
    [UdonBehaviourSyncMode(BehaviourSyncMode.None)]
    public class AutoPlay : UdonSharpBehaviour
    {
        [SerializeField] Controller _controller;
        [SerializeField] AutoPlayMode _autoPlayMode = AutoPlayMode.Off;
        [SerializeField, Range(0, 60)] float _delay;
        [SerializeField] VideoPlayerType _videoPlayerType;
        [SerializeField] string _title;
        [SerializeField] VRCUrl _url;
        [SerializeField] int _playlistIndex = 0;
        [SerializeField] int _playlistTrackIndex = 0;

        // void Start()
        // {
        //     if (!Networking.IsMaster && !_controller.IsLocal) return;
        //     SendCustomEventDelayedSeconds(nameof(PlayDefaultTrack), _delay);
        // }

        public void PlayDefaultTrack()
        {
            if (_controller.IsPlaying) return;
            
            // FavoriteManager が null = OnPlayerRestored() 未実行なので待つ
            FavoriteManager favoriteManager = _controller.FavoriteManager;
            if (favoriteManager == null) return;

            // FavoriteManager の defaultUrl（なければ fallback）を優先
            VRCUrl defaultUrl = favoriteManager.GetDefaultUrl();
            string defaultTitle = favoriteManager.GetDefaultTitle();
            if (defaultUrl != null && !string.IsNullOrEmpty(defaultUrl.Get()))
            {
                Track track = Track.New(_controller.VideoPlayerType, defaultTitle ?? defaultUrl.Get(), defaultUrl);
                _controller.PlayTrack(track);
                Debug.Log($"[AutoPlay] Playing default video from FavoriteManager: {defaultTitle ?? defaultUrl.Get()}");
                return;
            }

            // defaultUrl も fallback もない場合は既存の動作
            switch(_autoPlayMode)
            {
                case AutoPlayMode.FromTrack:
                    Track track = Track.New(_videoPlayerType, _title, _url);
                    _controller.PlayTrack(track);
                    break;
                case AutoPlayMode.FromPlaylist:
                    Playlist playlist = _controller.Playlists[_playlistIndex];
                    if (_playlistTrackIndex < 0) _controller.PlayRandomTrack(playlist);
                    else _controller.PlayTrack(playlist, _playlistTrackIndex);
                    break;
            }
        }
    }
}