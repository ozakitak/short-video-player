using UnityEngine;
using UnityEditor;
using VRC.SDKBase;
using UdonSharpEditor;

public class UrlPoolBaker : Editor
{
    const string BASE_URL = "https://shortvideo-world.shortvideo-world.workers.dev/vrcurl/";
    const int POOL_SIZE = 3000;

    [MenuItem("ShortVideoWorld/Bake URL Pool")]
    static void BakeUrlPool()
    {
        ShortVideoPlayer player = FindObjectOfType<ShortVideoPlayer>();
        if (player == null)
        {
            Debug.LogError("[UrlPoolBaker] ShortVideoPlayer がシーンに見つかりません。");
            return;
        }

        VRCUrl[] pool = new VRCUrl[POOL_SIZE];
        for (int i = 0; i < POOL_SIZE; i++)
        {
            pool[i] = new VRCUrl(BASE_URL + i);
        }

        // UdonSharpのプロキシ経由でフィールドをセット
        player.SetProgramVariable("_urlPool", pool);
        UdonSharpEditorUtility.CopyProxyToUdon(player);

        EditorUtility.SetDirty(player);
        Debug.Log($"[UrlPoolBaker] {POOL_SIZE}件のURLを焼き込みました。");
    }
}
