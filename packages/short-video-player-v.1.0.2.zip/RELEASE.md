# リリース手順

## 毎回やること

1. `package.json` の `version` を上げる（例: `1.0.7` → `1.0.8`）

2. `com.moutaindw.favorite-yama-player` フォルダを zip 圧縮
   - フォルダを右クリック →「送る」→「圧縮（zip形式）フォルダー」
   - ファイル名を `com.moutaindw.favorite-yama-player-{バージョン}.zip` に変更

3. GitHub の [ozakitak/favorite-yama-player](https://github.com/ozakitak/favorite-yama-player) を開く

4. `packages/` フォルダに zip をアップロード
   - 「Add file → Upload files」

5. `index.json` を GitHub 上で編集（鉛筆アイコン）
   - 最新バージョンのエントリをコピーして新バージョン分を追加：
   ```json
   "1.0.8": {
     "name": "com.moutaindw.favorite-yama-player",
     "displayName": "Favorite Yama Player (Modified)",
     "version": "1.0.8",
     "url": "https://ozakitak.github.io/favorite-yama-player/packages/com.moutaindw.favorite-yama-player-1.0.8.zip"
   }
   ```
   - 「Commit changes」で保存

6. 数分後に GitHub Pages が更新されて VCC から利用可能になる
